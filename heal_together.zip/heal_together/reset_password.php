<?php
session_start();
include("connection.php");

if (!isset($_SESSION['email'])) {
    echo "<script>alert('Unauthorized access! Please try again.'); window.location='forgot_password.php';</script>";
    exit;
}

if (isset($_POST['reset'])) {
    $new_pass = mysqli_real_escape_string($conn, $_POST['password']);
    $confirm_pass = mysqli_real_escape_string($conn, $_POST['conpassword']);
    $email = $_SESSION['email'];

    if ($new_pass != $confirm_pass) {
        echo "<script>alert('Passwords do not match!');</script>";
        exit;
    }

    // ✅ If later you want hashing:
    // $new_pass = password_hash($new_pass, PASSWORD_DEFAULT);

    mysqli_query($conn, "UPDATE form SET password='$new_pass', conpassword='$confirm_pass' WHERE email='$email'");

    echo "<script>alert('Password reset successfully!'); window.location='index.php';</script>";
    session_destroy();
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
  <title>Reset Password</title>
</head>
<body style="background:#D071F9; font-family:Arial;">
  <div style="margin:100px auto; width:320px; background:#fff; padding:25px; border-radius:10px;">
    <h2>Reset Password</h2>
    <form method="POST">
        <input type="password" name="password" placeholder="Enter new password" required style="width:90%; padding:8px;"><br><br>
        <input type="password" name="conpassword" placeholder="Confirm new password" required style="width:90%; padding:8px;"><br><br>

        <input type="submit" name="reset" value="Update Password" style="width:100%; padding:8px; background:#D071F9; color:white; border:none;">
    </form>
  </div>
</body>
</html>
