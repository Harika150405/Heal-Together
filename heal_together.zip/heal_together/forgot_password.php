
<?php
session_start();
include("connection.php");

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'PHPMailer/src/Exception.php';
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';

if (isset($_POST['submit'])) {
    $email = mysqli_real_escape_string($conn, $_POST['email']);

    $check = mysqli_query($conn, "SELECT * FROM form WHERE email='$email'");
    if (mysqli_num_rows($check) > 0) {
        $otp = rand(100000, 999999);
        $_SESSION['otp'] = $otp;
        $_SESSION['email'] = $email;
        $_SESSION['otp_time'] = time(); 
        $mail = new PHPMailer(true);
        try {
            $mail->isSMTP();
            $mail->Host = 'smtp.gmail.com';
            $mail->SMTPAuth = true;
            $mail->Username = 'yanapartiharika@gmail.com';     
            $mail->Password = 'bcztdzhhwlelzssz';       
            $mail->SMTPSecure = 'ssl';
            $mail->Port = 465;


            $mail->setFrom('yanapartiharika@gmail.com', 'Heal Together');
            $mail->addAddress($email);

            $mail->isHTML(true);
            $mail->Subject = 'Password Reset OTP';
            $mail->Body    = "Your OTP for password reset is: <b>$otp</b>. It is valid for 5 minutes.";

            $mail->send();
            echo "<script>alert('OTP sent to your email!'); window.location='verify_otp.php';</script>";
            exit;
        } catch (Exception $e) {
            echo "<script>alert('Mailer Error: {$mail->ErrorInfo}');</script>";
        }
    } else {
        echo "<script>alert('Email not found!');</script>";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Forgot Password</title>
</head>
<body style="background:#D071F9; font-family:Arial;">
    <div style="margin:100px auto; width:300px; background:#fff; padding:20px; border-radius:10px;">
        <h2>Forgot Password</h2>
        <form method="POST">
            <input type="email" name="email" placeholder="Enter Email" required style="width:90%; padding:8px;"><br><br>
            <input type="submit" name="submit" value="Send OTP" style="width:100%; padding:8px; background:#D071F9; color:white; border:none;">
        </form>
        <br>
        <div style="text-align:center;">
            <a href="index.php" style="color:#0a63d8; text-decoration:none;">&larr; Back to Login</a>
        </div>
    </div>
</body>
</html>
