<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Community Services - Heal Together</title>
  <link rel="stylesheet" href="community_style.css?v=1">
</head>
<body>
  <h1>Community Services - Heal Together</h1>
  <p>Connect with others facing similar health challenges. Join groups for support and shared experiences.</p>


  <div class="groups-container" id="groupsContainer">
    <div class="group-card">
      <img src="logos/diabetes" alt="Diabetes Logo">
      <h3>Diabetes</h3>
      <p>A chronic condition that affects how your body turns food into energy. Share tips on management and daily life.</p>
      <p class="tagline">Stronger every day, one step at a time.</p>
      <button onclick="joinGroup('Diabetes')">Join</button>
    </div>

    <div class="group-card">
      <img src="logos/hypertension" alt="Hypertension Logo">
      <h3>Hypertension</h3>
      <p>High blood pressure that can lead to serious health issues. Discuss lifestyle changes and treatments.</p>
      <p class="tagline">Stay calm, stay strong.</p>
     
       <button onclick="joinGroup('Hypertension')">Join</button>

    </div>

    <div class="group-card">
      <img src="logos/depression.png" alt="Depression Logo">
      <h3>Depression</h3>
      <p>A mood disorder characterized by persistent sadness and loss of interest. Find support and coping strategies.</p>
      <p class="tagline">Hope is stronger than despair.</p>
     
       <button onclick="joinGroup('Depression')">Join</button>

    </div>

    <div class="group-card">
      <img src="logos/anxiety.png" alt="Anxiety Logo">
      <h3>Anxiety</h3>
      <p>A mental health disorder with excessive worry and fear. Connect with others to share experiences and advice.</p>
      <p class="tagline">Breathe. Heal. Grow.</p>
      
        <button onclick="joinGroup('Anxiety')">Join</button>
    </div>

    <div class="group-card">
      <img src="logos/arthritis.png" alt="Arthritis Logo">
      <h3>Arthritis</h3>
      <p>Inflammation of the joints causing pain and stiffness. Exchange tips on pain management and daily activities.</p>
      <p class="tagline">Keep moving, keep shining.</p>
      
      <button onclick="joinGroup('Arthritis')">Join</button>
    </div>

    <!-- Cancer Subcategories -->
    <div class="group-card">
      <img src="logos/breast cancer.png" alt="Breast Cancer Logo">
      <h3>Breast Cancer</h3>
      <p>Support for those affected by breast cancer. Share experiences, treatments, and resources.</p>
      <p class="tagline">Strength in pink, hope in every step.</p>
       <button  onclick="joinGroup('Breast Cancer')">Join</button>
    </div>

    <div class="group-card">
      <img src="logos/blood cancer.png" alt="Blood Cancer Logo">
      <h3>Blood Cancer</h3>
      <p>Community for blood cancer patients. Discuss leukemia, lymphoma, and support options.</p>
      <p class="tagline">Every drop of courage counts.</p>
      
      <button onclick="joinGroup('Blood Cancer')">Join</button>
    </div>

    <div class="group-card">
      <img src="logos/lung cancer.png" alt="Lung Cancer Logo">
      <h3>Lung Cancer</h3>
      <p>Support group for lung cancer survivors and patients. Share coping strategies.</p>
      <p class="tagline">Every breath is a victory, every step is hope.</p>
      
      <button  onclick="joinGroup('Lung Cancer')">Join</button>
    </div>

    <!-- Other Diseases -->
    <div class="group-card">
      <img src="logos/covid-19.png" alt="COVID-19 Logo">
      <h3>COVID-19</h3>
      <p>Long-term effects and recovery from COVID-19. Connect with others for support.</p>
      <p class="tagline">Healing together, stronger tomorrow.</p>
      
      <button  onclick="joinGroup('COVID-19')">Join</button>
    </div>

    <div class="group-card">
      <img src="logos/chronic kidney disease.png" alt="Chronic Kidney Disease Logo">
      <h3>Chronic Kidney Disease</h3>
      <p>Management and support for chronic kidney disease. Share dialysis experiences.</p>
      <p class="tagline">Together through every dialysis and beyond.</p>
      
      <button  onclick="joinGroup('Chronic Kidney Disease')">Join</button>
    </div>

    <div class="group-card">
      <img src="logos/epilepsy.png" alt="Epilepsy Logo">
      <h3>Epilepsy</h3>
      <p>Support for epilepsy patients. Discuss seizures, medications, and daily life.</p>
      <p class="tagline">Breaking the silence, embracing strength.</p>
      
      <button  onclick="joinGroup('Epilepsy')">Join</button>
    </div>

    <div class="group-card">
      <img src="logos/mental health disorders.png" alt="Down Syndrome Logo">
      <h3>Down Syndrome</h3>
      <p>Community for families and individuals with Down Syndrome. Share resources and stories.</p>
      <p class="tagline">Celebrating abilities, not disabilities.</p>
     
      <button  onclick="joinGroup('Down Syndrome')">Join</button>
    </div>

    <div class="group-card">
      <img src="logos/cardiovascular disease.png" alt="Cardiovascular Diseases Logo">
      <h3>Cardiovascular Diseases</h3>
      <p>Heart health and cardiovascular support. Discuss prevention and treatments.</p>
      <p class="tagline">Healing hearts, inspiring lives.</p>
      
      <button  onclick="joinGroup('Cardiovascular Diseases')">Join</button>
    </div>

    <div class="group-card">
      <img src="logos/COPD.png" alt="COPD Logo">
      <h3>COPD</h3>
      <p>Chronic Obstructive Pulmonary Disease support. Breathing techniques and lifestyle tips.</p>
      <p class="tagline">Endurance is power.</p>
     
      <button  onclick="joinGroup('COPD')">Join</button>
    </div>

    <div class="group-card">
      <img src="logos/hivaids.png" alt="HIV/AIDS Logo">
      <h3>HIV/AIDS</h3>
      <p>Support for HIV/AIDS patients. Discuss treatments, stigma, and living positively.</p>
      <p class="tagline">Living with courage, thriving with hope.</p>
     
      <button  onclick="joinGroup('HIV/AIDS')">Join</button>
    </div>

    <div class="group-card">
      <img src="logos/PTSD.png" alt="PTSD Logo">
      <h3>PTSD</h3>
      <p>Post-Traumatic Stress Disorder support. Share coping mechanisms and therapy experiences.</p>
      <p class="tagline">Healing is not forgetting, it’s learning to live again.</p>
     
      <button  onclick="joinGroup('PTSD')">Join</button>
    </div>

    <div class="group-card">
      <img src="logos/schizophrenia.png" alt="Schizophrenia Logo">
      <h3>Schizophrenia</h3>
      <p>Support for schizophrenia. Discuss symptoms, medications, and recovery.</p>
      <p class="tagline">Breaking stigma, embracing strength of mind.</p>
     
      <button  onclick="joinGroup('Schizophrenia')">Join</button>
    </div>

    <div class="group-card">
      <img src="logos/lupus.png" alt="Lupus Logo">
      <h3>Lupus</h3>
      <p>Autoimmune disease support for lupus patients. Share flare management tips.</p>
      <p class="tagline">Living with strength, not just survival.</p>
      
      <button  onclick="joinGroup('Lupus')">Join</button>
    </div>

    <div class="group-card">
      <img src="logos/mutiple sclerosis.png" alt="Multiple Sclerosis Logo">
      <h3>Multiple Sclerosis</h3>
      <p>MS support group. Discuss symptoms, treatments, and mobility aids.</p>
      <p class="tagline">Strength in motion, hope in every step.</p>
     
      <button  onclick="joinGroup('Multiple Sclerosis')">Join</button>
    </div>

    <div class="group-card">
      <img src="logos/alzheimer's.png" alt="Alzheimer's Logo">
      <h3>Alzheimer's</h3>
      <p>Support for Alzheimer's patients and caregivers. Share care strategies.</p>
      <p class="tagline">Compassion in every memory.</p>
      
      <button  onclick="joinGroup('Alzheimer\'s')">Join</button>
    </div>

    <!-- Woman's Health Subcategories -->
    <div class="group-card">
      <img src="logos/PCOD.png" alt="PCOS/PCOD Logo">
      <h3>PCOS/PCOD</h3>
      <p>Polycystic Ovary Syndrome support. Discuss symptoms, fertility, and management.</p>
      <p class="tagline">Stronger than the struggle.</p>
      
      <button  onclick="joinGroup('PCOS/PCOD')">Join</button>
    </div>

    <div class="group-card">
      <img src="logos/infertility.png" alt="Infertility Support Logo">
      <h3>Infertility Support</h3>
      <p>Support for couples facing infertility. Share experiences and resources.</p>
      <p class="tagline">Hope grows here.</p>
     
      <button  onclick="joinGroup('Infertility Support')">Join</button>
    </div>

    <div class="group-card">
      <img src="logos/endometriosis.png" alt="Endometriosis Logo">
      <h3>Endometriosis</h3>
      <p>Support for endometriosis patients. Discuss pain management and treatments.</p>
      <p class="tagline">Pain does not define you.</p>
      
      <button  onclick="joinGroup('Endometriosis')">Join</button>
    </div>

    <div class="group-card">
      <img src="logos/menopause.png" alt="Menopause Health Logo">
      <h3>Menopause Health</h3>
      <p>Menopause support. Share hot flashes, mood changes, and health tips.</p>
      <p class="tagline">Embracing change with grace.</p>
      
      <button  onclick="joinGroup('Menopause Health')">Join</button>
    </div>
  </div>

  <script src="community-services.js"></script>
</body>
<script>
function joinGroup(groupName) {
    fetch("chat/join_group.php", {
        method: "POST",
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body: "group_name=" + encodeURIComponent(groupName)
    })
    .then(response => response.text())
    .then(data => {
        console.log("Server Response:", data);

        if (data.trim() === "success") {
            window.location.href = "chat/chat.php?group=" + encodeURIComponent(groupName);
        } 
        else if (data.trim() === "already") {
            alert("You already joined this group!");
            window.location.href = "chat/chat.php?group=" + encodeURIComponent(groupName);}

        else {
            alert("Error: " + data);
        }
    })
    .catch(err => console.error(err));
}
</script>

</html>
