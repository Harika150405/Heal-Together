<?php
session_start();
include 'dbconnection.php';
error_reporting(E_ALL);
ini_set('display_errors', 1);

if (!isset($_SESSION['username'])) {
    die("You must be logged in to like a story.");
}

$username = $_SESSION['username'];

if (isset($_POST['story_id'])) {
    $story_id = intval($_POST['story_id']);

    // Check if already liked
    $check = $conn->prepare("SELECT * FROM likes WHERE story_id = ? AND username = ?");
    $check->bind_param("is", $story_id, $username);
    $check->execute();
    $result = $check->get_result();

    if ($result->num_rows === 0) {
        $insert = $conn->prepare("INSERT INTO likes (story_id, username) VALUES (?, ?)");
        $insert->bind_param("is", $story_id, $username);
        $insert->execute();
        $insert->close();
        echo "liked";
    } else {
        // Remove like if already liked
        $delete = $conn->prepare("DELETE FROM likes WHERE story_id = ? AND username = ?");
        $delete->bind_param("is", $story_id, $username);
        $delete->execute();
        $delete->close();
        echo "unliked";
    }

    $check->close();
}
?>