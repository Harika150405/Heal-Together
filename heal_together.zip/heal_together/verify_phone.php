<?php
include("connection.php");

if (isset($_POST['verify'])) {
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $otp = mysqli_real_escape_string($conn, $_POST['otp']);

    $query = "SELECT * FROM form WHERE email='$email' AND verification_code='$otp'";
    $result = mysqli_query($conn, $query);

    if (mysqli_num_rows($result) > 0) {
        $update = "UPDATE form SET phone_verified=1, verification_code=NULL WHERE email='$email'";
        mysqli_query($conn, $update);
        echo "<script>alert('Phone verified successfully!'); window.location='index.php';</script>";
    } else {
        echo "<script>alert('Invalid OTP');</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Verify Phone</title>
<link rel="stylesheet" href="form-style.css">
</head>
<body>
<div class="container">
	<div class="title">Phone Verification</div>
	<form method="POST">
		<div class="form">
			<div class="input_field">
				<label>Email</label>
				<input type="email" class="input" name="email" required>
			</div>
			<div class="input_field">
				<label>Enter OTP</label>
				<input type="text" class="input" name="otp" required>
			</div>
			<div class="input_field">
				<input type="submit" value="Verify" class="btn" name="verify">
			</div>
		</div>
	</form>
</div>
</body>
</html>