<?php 
include("connection.php");
session_start();
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'PHPMailer/src/Exception.php';
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';

?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Registration Form</title>
  <link rel="stylesheet" href="form-style.css">
</head>
<body>
  <div class="container">
    <div class="title">Registration Form</div>
    <form method="POST">
      <div class="form">

        <div class="input_field">
          <label>Username</label>
          <input type="text" class="input" name="username" required>
        </div>

        <div class="input_field">
          <label>First Name</label>
          <input type="text" class="input" name="fname" required>
        </div>

        <div class="input_field">
          <label>Last Name</label>
          <input type="text" class="input" name="lname" required>
        </div>

        <div class="input_field">
          <label>Password</label>
          <input type="password" class="input" name="password" required>
        </div>

        <div class="input_field">
          <label>Confirm Password</label>
          <input type="password" class="input" name="conpassword" required>
        </div>

        <div class="input_field">
          <label>Gender</label>
          <div class="selectbox">
            <select name="gender" required>
              <option value="">Select</option>
              <option value="male">Male</option>
              <option value="female">Female</option>
            </select>
          </div>
        </div>

        <div class="input_field">
          <label>Email Address</label>
          <input type="email" class="input" name="email" required>
        </div>

        <div class="input_field">
          <label>Phone Number</label>
          <input type="text" class="input" name="phone" required pattern="[6-9][0-9]{9}" title="Enter a valid 10-digit Indian mobile number">
        </div>

        <div class="input_field">
          <label>Address</label>
          <textarea class="textarea" name="address" required></textarea>
        </div>

        <div class="input_field">
          <label class="check">
            <input type="checkbox" required>
            <span class="checkmark"></span>
          </label>
          <p>Agree to terms and conditions</p>
        </div>

        <div class="input_field">
          <input type="submit" value="Register" class="btn" name="register">
        </div>
      </div>
    </form>
  </div>
</body>
</html>

<?php
if (isset($_POST['register'])) {
  $username = mysqli_real_escape_string($conn, $_POST['username']);
  $fname = mysqli_real_escape_string($conn, $_POST['fname']);
  $lname = mysqli_real_escape_string($conn, $_POST['lname']);
  $pwd = $_POST['password'];
  $cpwd = $_POST['conpassword'];
  $gender = $_POST['gender'];
  $email = mysqli_real_escape_string($conn, $_POST['email']);
  $phone = mysqli_real_escape_string($conn, $_POST['phone']);
  $address = mysqli_real_escape_string($conn, $_POST['address']);

  if ($pwd !== $cpwd) {
    echo "<script>alert('Passwords do not match');</script>";
    exit();
  }

  $check_user = "SELECT * FROM form WHERE email='$email' OR username='$username'";
  $result = mysqli_query($conn, $check_user);
  if (mysqli_num_rows($result) > 0) {
    echo "<script>alert('Username or Email already registered');</script>";
    exit();
  }

  $query = "INSERT INTO form (username, fname, lname, password, conpassword, gender, email, phone, address, verified) 
        VALUES ('$username', '$fname', '$lname', '$pwd', '$cpwd', '$gender', '$email', '$phone', '$address', 0)";
  $data = mysqli_query($conn, $query);

  if ($data) {
    $otp = rand(100000, 999999);
    $_SESSION['otp'] = $otp;
    $_SESSION['email'] = $email;

    // --- Send OTP via your SMTP mailer ---
    $mail = new PHPMailer(true);
    $mail->isSMTP();
    $mail->Host = 'smtp.gmail.com'; // adjust to your SMTP
    $mail->SMTPAuth = true;
    $mail->Username = 'yanapartiharika@gmail.com'; // your email
    $mail->Password = 'bcztdzhhwlelzssz'; // app password
    $mail->SMTPSecure = 'tls';
    $mail->Port = 587;
    $mail->setFrom('yanapartiharika@gmail.com', 'Heal_together');
    $mail->addAddress($email);
    $mail->isHTML(true);
    $mail->Subject = 'Your OTP Verification Code';
    $mail->Body = "<p>Hello <b>$username</b>,<br>Your verification code is: <b>$otp</b></p>";

    if ($mail->send()) {
      header("Location: verify_registration_otp.php");
      exit();
    } else {
      echo "<script>alert('Failed to send OTP email. Try again.');</script>";
    }
  } else {
    echo "<script>alert('Failed to register. Please try again.');</script>";
  }
}
?>
