<?php
session_start();
include 'dbconnection.php';
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Make sure the user is logged in
if (!isset($_SESSION['username'])) {
    die("You must be logged in to edit your story.");
}

// Get story ID from URL
if (!isset($_GET['id'])) {
    die("Invalid story ID.");
}

$story_id = intval($_GET['id']);
$username = $_SESSION['username'];

// Fetch the story only if it belongs to the logged-in user
$stmt = $conn->prepare("SELECT * FROM stories WHERE id = ? AND name = ?");
$stmt->bind_param("is", $story_id, $username);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    die("You can only edit your own stories.");
}

$story = $result->fetch_assoc();

// If the form is submitted, update the story
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $community = $_POST['community'];
    $story_text = $_POST['story'];

    $update = $conn->prepare("UPDATE stories SET community = ?, story = ? WHERE id = ? AND name = ?");
    $update->bind_param("ssis", $community, $story_text, $story_id, $username);
    $update->execute();

    echo "<script>alert('Story updated successfully!'); window.location.href='viewstory.php';</script>";
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Edit Your Story</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">

<style>
body {
  background: linear-gradient(120deg, #fdf6f0, #ffe7d6);
  font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
}

.edit-container {
  max-width: 700px;
  margin: 50px auto;
  background: #ffffff;
  padding: 40px;
  border-radius: 25px;
  box-shadow: 0px 10px 30px rgba(0,0,0,0.1);
}

h1 {
  color: #f47c7c;
  text-align: center;
  margin-bottom: 30px;
}

label {
  font-weight: 600;
  color: #333;
}

input, textarea {
  border-radius: 15px;
  border: 1px solid #ccc;
  padding: 12px;
  width: 100%;
  margin-top: 5px;
  margin-bottom: 20px;
  font-size: 1rem;
}

.btn-update {
  background-color: #f47c7c;
  color: #fff;
  border: none;
  padding: 12px 30px;
  border-radius: 50px;
  font-size: 1.1rem;
  font-weight: 600;
}

.btn-update:hover {
  background-color: #e06363;
  transform: scale(1.05);
}

.back-home {
  display: block;
  text-align: center;
  margin-top: 20px;
  color: #f47c7c;
  text-decoration: none;
  font-weight: 500;
}

.back-home:hover {
  text-decoration: underline;
}
</style>
</head>
<body>

<div class="edit-container">
  <h1>Edit Your Story ✏️</h1>
  <form method="POST">
    <label for="community">Community</label>
    <input type="text" id="community" name="community" value="<?= htmlspecialchars($story['community']) ?>" required>

    <label for="story">Your Story</label>
    <textarea id="story" name="story" rows="8" required><?= htmlspecialchars($story['story']) ?></textarea>

    <button type="submit" class="btn btn-update w-100">Update Story</button>
  </form>

  <a href="viewstory.php" class="back-home">← Back to Stories</a>
</div>

</body>
</html>