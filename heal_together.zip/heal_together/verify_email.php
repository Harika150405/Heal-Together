<?php
include("connection.php");

if (isset($_GET['token'])) {
    $token = $_GET['token'];

    $query = "SELECT * FROM form WHERE email_token='$token'";
    $result = mysqli_query($conn, $query);

    if (mysqli_num_rows($result) > 0) {
        $update = "UPDATE form SET email_verified=1, email_token=NULL WHERE email_token='$token'";
        mysqli_query($conn, $update);
        echo "<script>alert('Email verified successfully!'); window.location='index.php';</script>";
    } else {
        echo "<script>alert('Invalid or expired link'); window.location='index.php';</script>";
    }
} else {
    echo "No token found.";
}
?>