<?php
session_start();
include 'dbconnection.php';
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Get logged-in username
$username = isset($_SESSION['username']) ? $_SESSION['username'] : '';

// Fetch stories
$result = $conn->query("SELECT * FROM stories ORDER BY created_at DESC");
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Community Stories</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">

<style>
body {
  background: linear-gradient(120deg, #fdf6f0, #e0f7f5);
  font-family: 'Poppins', sans-serif;
  min-height: 100vh;
}

.header {
  text-align: center;
  padding: 50px 20px 20px;
}
.header h1 {
  font-weight: 700;
  color: #2f5d50;
}
.header p {
  color: #5e746e;
  font-size: 1.1rem;
}

.story-card {
  background: #fff;
  border-radius: 20px;
  box-shadow: 0px 8px 25px rgba(0, 0, 0, 0.1);
  padding: 25px;
  margin-bottom: 30px;
  transition: transform 0.3s ease, box-shadow 0.3s ease;
}
.story-card:hover {
  transform: translateY(-8px);
  box-shadow: 0px 12px 35px rgba(0, 0, 0, 0.15);
}
.story-card h4 {
  color: #f47c7c;
  font-weight: 600;
}
.story-card small {
  color: #666;
}
.story-card p {
  color: #333;
  font-size: 1.05rem;
  margin-top: 15px;
}

.edit-btn, .delete-btn {
  border: none;
  border-radius: 50px;
  padding: 8px 18px;
  font-weight: 600;
  color: #fff;
  transition: all 0.3s ease;
  margin-right: 10px;
}
.edit-btn {
  background-color: #f7a440;
}
.edit-btn:hover {
  background-color: #e58c00;
}
.delete-btn {
  background-color: #f06262;
}
.delete-btn:hover {
  background-color: #d94a4a;
}

.like-btn {
  background: none;
  border: none;
  color: #f47c7c;
  font-size: 1.3rem;
  cursor: pointer;
}
.like-btn:hover {
  transform: scale(1.2);
}

.comment-section {
  margin-top: 20px;
  border-top: 1px solid #eee;
  padding-top: 10px;
}
.comment {
  margin-top: 10px;
  padding: 8px 15px;
  background: #f9f9f9;
  border-radius: 10px;
}
.comment strong {
  color: #2f5d50;
}
.comment small {
  color: #888;
}

.comment-form textarea {
  width: 100%;
  border-radius: 10px;
  border: 1px solid #ccc;
  padding: 8px;
  resize: none;
  margin-top: 5px;
}
.comment-form button {
  margin-top: 8px;
  background-color: #f47c7c;
  color: white;
  border: none;
  border-radius: 50px;
  padding: 6px 18px;
}
.comment-form button:hover {
  background-color: #e06363;
}

.back-btn {
  display: inline-block;
  background-color: #2f5d50;
  color: white;
  text-decoration: none;
  border-radius: 50px;
  padding: 12px 30px;
  font-weight: 600;
  margin: 40px auto;
  transition: background-color 0.3s ease, transform 0.3s ease;
}
.back-btn:hover {
  background-color: #3e7d6e;
  transform: scale(1.05);
  color: white;
}
</style>
</head>

<body>

<div class="header">
  <h1>💫 Community Stories</h1>
  <p>Real voices. Real experiences. Read the inspiring stories shared by our members below.</p>
</div>

<div class="container">
  <div class="row justify-content-center">
    <?php if ($result->num_rows > 0): ?>
      <?php while ($row = $result->fetch_assoc()): 
        $story_id = $row['id'];

        // Count likes
        $likes_result = $conn->query("SELECT COUNT(*) AS total FROM likes WHERE story_id = $story_id");
        $likes = $likes_result->fetch_assoc()['total'];

        // Fetch comments
        $comments_result = $conn->query("SELECT * FROM comments WHERE story_id = $story_id ORDER BY created_at ASC");
      ?>
        <div class="col-md-8">
          <div class="story-card">
            <h4><?= htmlspecialchars($row['name']) ?></h4>
            <small><strong>Community:</strong> <?= htmlspecialchars($row['community']) ?></small>
            <p><?= nl2br(htmlspecialchars($row['story'])) ?></p>
            <small><em>Posted on <?= $row['created_at'] ?></em></small>

            <!-- Like Button -->
            <form action="like_story.php" method="POST" style="display:inline;">
              <input type="hidden" name="story_id" value="<?= $story_id ?>">
              <button type="submit" class="like-btn">❤️ <?= $likes ?></button>
            </form>

            <?php if (isset($_SESSION['username']) && $_SESSION['username'] === $row['name']): ?>
              <div class="mt-3">
                <a href="edit_story.php?id=<?= $story_id ?>" class="btn edit-btn">Edit</a>
                <a href="delete_story.php?id=<?= $story_id ?>" class="btn delete-btn" onclick="return confirm('Are you sure you want to delete this story?');">Delete</a>
              </div>
            <?php endif; ?>

            <!-- Comments Section -->
            <div class="comment-section">
              <h6>Comments</h6>
              <?php while ($comment = $comments_result->fetch_assoc()): ?>
                <div class="comment">
                  <strong><?= htmlspecialchars($comment['username']) ?></strong>
                  <small><?= $comment['created_at'] ?></small>
                  <p><?= nl2br(htmlspecialchars($comment['comment'])) ?></p>
                </div>
              <?php endwhile; ?>

              <!-- Add Comment -->
              <?php if (isset($_SESSION['username'])): ?>
                <form action="comment_story.php" method="POST" class="comment-form">
                  <input type="hidden" name="story_id" value="<?= $story_id ?>">
                  <textarea name="comment" rows="2" placeholder="Write a comment..." required></textarea>
                  <button type="submit">Post</button>
                </form>
              <?php else: ?>
                <p><em>Login to comment.</em></p>
              <?php endif; ?>
            </div>

          </div>
        </div>
      <?php endwhile; ?>
    <?php else: ?>
      <p class="text-center">No stories have been shared yet.</p>
    <?php endif; ?>
  </div>

  <div class="text-center">
    <a href="index_home.html" class="back-btn">← Back to Home</a>
  </div>
</div>

</body>
</html>