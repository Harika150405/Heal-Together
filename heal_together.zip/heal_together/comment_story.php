<?php
session_start();
include 'dbconnection.php';
error_reporting(E_ALL);
ini_set('display_errors', 1);

if (!isset($_SESSION['username'])) {
    die("You must be logged in to comment.");
}

$username = $_SESSION['username'];

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $story_id = intval($_POST['story_id']);
    $comment = trim($_POST['comment']);

    if (!empty($comment)) {
        $stmt = $conn->prepare("INSERT INTO comments (story_id, username, comment) VALUES (?, ?, ?)");
        $stmt->bind_param("iss", $story_id, $username, $comment);
        $stmt->execute();
        $stmt->close();

        echo "<script>alert('Comment added successfully!'); window.location.href='viewstory.php';</script>";
    } else {
        echo "<script>alert('Please enter a comment before submitting.'); window.history.back();</script>";
    }
} else {
    header("Location: viewstory.php");
    exit;
}
?>