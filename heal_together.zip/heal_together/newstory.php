<?php
session_start();
include 'dbconnection.php';
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Get logged-in user's username
$username = isset($_SESSION['username']) ? $_SESSION['username'] : '';

// Temporary connection to fetch community groups from "responsiveform"
$community_conn = new mysqli("localhost", "root", "", "responsiveform");

if ($community_conn->connect_error) {
    die("Connection failed: " . $community_conn->connect_error);
}

$community_query = $community_conn->query("SELECT group_name FROM community_groups");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Write Your Story</title>

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom Styles -->
    <style>
        body {
            background: linear-gradient(120deg, #fdf6f0, #ffe7d6);
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        .story-container {
            max-width: 700px;
            margin: 50px auto;
            background: #ffffff;
            padding: 40px;
            border-radius: 25px;
            box-shadow: 0px 10px 30px rgba(0,0,0,0.1);
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }

        .story-container:hover {
            transform: translateY(-5px);
            box-shadow: 0px 15px 40px rgba(0,0,0,0.2);
        }

        h1 {
            color: #f47c7c;
            text-align: center;
            margin-bottom: 30px;
        }

        label {
            font-weight: 600;
            color: #333;
        }

        input, textarea, select {
            border-radius: 15px;
            border: 1px solid #ccc;
            padding: 12px;
            width: 100%;
            margin-top: 5px;
            margin-bottom: 20px;
            font-size: 1rem;
            transition: all 0.3s ease;
        }

        input:focus, textarea:focus, select:focus {
            border-color: #f47c7c;
            box-shadow: 0px 0px 10px rgba(244,124,124,0.3);
            outline: none;
        }

        .btn-submit {
            background-color: #f47c7c;
            color: #fff;
            border: none;
            padding: 12px 30px;
            border-radius: 50px;
            font-size: 1.1rem;
            font-weight: 600;
            transition: all 0.3s ease;
        }

        .btn-submit:hover {
            background-color: #e06363;
            transform: scale(1.05);
        }

        .back-home {
            display: block;
            text-align: center;
            margin-top: 20px;
            color: #f47c7c;
            text-decoration: none;
            font-weight: 500;
        }

        .back-home:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>

<div class="story-container">
    <h1>Share Your Story 💖</h1>

    <form action="submit_story.php" method="POST">
        <!-- Auto-filled username -->
        <label for="name">Your Name</label>
        <input type="text" id="name" name="name" value="<?php echo htmlspecialchars($username); ?>" readonly required>

        <!-- Dynamic Community dropdown -->
        <label for="community">Community</label>
        <select id="community" name="community" required>
            <option value="">-- Select Your Community --</option>
            <?php 
            if ($community_query && $community_query->num_rows > 0) {
                while ($row = $community_query->fetch_assoc()) {
                    echo '<option value="' . htmlspecialchars($row['group_name']) . '">' . htmlspecialchars($row['group_name']) . '</option>';
                }
            } else {
                echo '<option value="">No communities available</option>';
            }
            ?>
        </select>

        <!-- Story box -->
        <label for="story">Your Story</label>
        <textarea id="story" name="story" rows="8" placeholder="Write your inspiring story here..." required></textarea>

        <!-- Submit button -->
        <button type="submit" class="btn btn-submit w-100">Submit Story</button>
    </form>

    <a href="index_home.html" class="back-home">← Back to Home</a>
</div>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>

<?php
$community_conn->close();
?>