<?php
include("connection.php");
session_start();

if (isset($_POST['verify_otp'])) {
    $otp = mysqli_real_escape_string($conn, $_POST['otp']);

    if (isset($_SESSION['otp']) && isset($_SESSION['email'])) {
        $stored_otp = $_SESSION['otp'];
        $email = $_SESSION['email'];

        if ($otp == $stored_otp) {
            $update = "UPDATE form SET verified=1 WHERE email='$email'";
            mysqli_query($conn, $update);

            // Clear session values
            unset($_SESSION['otp']);
            unset($_SESSION['email']);

            // ✅ Redirect to index.php instead of login.php
            echo "<script>alert('Email verified successfully!'); window.location='index.php';</script>";
        } else {
            echo "<script>alert('Invalid OTP. Please try again.');</script>";
        }
    } else {
        echo "<script>alert('Session expired. Please register again.'); window.location='form.php';</script>";
    }
}
?>

<!DOCTYPE html>
<html lang='en'>
<head>
    <meta charset='UTF-8'>
    <meta name='viewport' content='width=device-width, initial-scale=1.0'>
    <title>Verify OTP</title>
    <link rel='stylesheet' href='form-style.css'>
</head>
<body>
    <div class='container'>
        <div class='title'>Verify Your Email</div>
        <form method='POST'>
            <div class='form'>
                <div class='input_field'>
                    <label>Enter OTP</label>
                    <input type='text' class='input' name='otp' required>
                </div>
                <div class='input_field'>
                    <input type='submit' value='Verify OTP' class='btn' name='verify_otp'>
                </div>
            </div>
        </form>
    </div>
</body>
</html>
