<?php
session_start();
include("connection.php");

// Check if user is logged in
if (!isset($_SESSION['username'])) {
    echo "<script>alert('Please login first!'); window.location='index.php';</script>";
    exit();
}

$username = $_SESSION['username'];

// Fetch user details
$query = "SELECT * FROM form WHERE username='$username'";
$data = mysqli_query($conn, $query);
$result = mysqli_fetch_assoc($data);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Profile</title>
    <link rel="stylesheet" href="form-style.css">
</head>
<body>
    <div class="container">
        <div class="title">Edit Profile</div>
        <form method="POST">
            <div class="form">

                <div class="input_field">
                    <label>Username</label>
                    <input type="text" class="input" value="<?php echo $result['username']; ?>" disabled>
                </div>

                <div class="input_field">
                    <label>First Name</label>
                    <input type="text" class="input" name="fname" value="<?php echo $result['fname']; ?>" required>
                </div>

                <div class="input_field">
                    <label>Last Name</label>
                    <input type="text" class="input" name="lname" value="<?php echo $result['lname']; ?>" required>
                </div>

                <div class="input_field">
                    <label>New Password</label>
                    <input type="password" class="input" name="password" placeholder="Leave blank to keep same">
                </div>

                <div class="input_field">
                    <label>Confirm Password</label>
                    <input type="password" class="input" name="conpassword" placeholder="Leave blank to keep same">
                </div>

                <div class="input_field">
                    <label>Gender</label>
                    <div class="selectbox">
                        <select name="gender" required>
                            <option value="">Select</option>
                            <option value="male" <?php if($result['gender']=='male') echo 'selected'; ?>>Male</option>
                            <option value="female" <?php if($result['gender']=='female') echo 'selected'; ?>>Female</option>
                        </select>
                    </div>
                </div>

                <div class="input_field">
                    <label>Email Address</label>
                    <input type="email" class="input" value="<?php echo $result['email']; ?>" disabled>
                </div>

                <div class="input_field">
                    <label>Phone Number</label>
                    <input type="text" class="input" name="phone" value="<?php echo $result['phone']; ?>" required>
                </div>

                <div class="input_field">
                    <label>Address</label>
                    <textarea class="textarea" name="address" required><?php echo $result['address']; ?></textarea>
                </div>

                <div class="input_field">
                    <input type="submit" value="Update Profile" class="btn" name="update">
                </div>

            </div>
        </form>
    </div>
</body>
</html>

<?php
if (isset($_POST['update'])) {

    $fname = $_POST['fname'];
    $lname = $_POST['lname'];
    $pwd = $_POST['password'];
    $cpwd = $_POST['conpassword'];
    $gender = $_POST['gender'];
    $phone = $_POST['phone'];
    $address = $_POST['address'];

    // If password fields filled → validate
    if (!empty($pwd) || !empty($cpwd)) {
        if ($pwd !== $cpwd) {
            echo "<script>alert('Passwords do not match');</script>";
            exit();
        }

        $query = "UPDATE form SET 
                    fname='$fname',
                    lname='$lname',
                    password='$pwd',
                    conpassword='$cpwd',
                    gender='$gender',
                    phone='$phone',
                    address='$address'
                  WHERE username='$username'";
    } else {  
        // Update without password change
        $query = "UPDATE form SET 
                    fname='$fname',
                    lname='$lname',
                    gender='$gender',
                    phone='$phone',
                    address='$address'
                  WHERE username='$username'";
    }

    $data = mysqli_query($conn, $query);

    if ($data) {
        echo "<script>alert('Profile Updated Successfully'); window.location='index_home.html';</script>";
    } else {
        echo "<script>alert('Failed to Update Profile');</script>";
    }
}
?>
