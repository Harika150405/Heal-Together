<?php
session_start();
include 'dbconnection.php';
error_reporting(E_ALL);
ini_set('display_errors', 1);

if (!isset($_SESSION['username'])) {
    die("You must be logged in to delete a story.");
}

$username = $_SESSION['username'];

if (isset($_GET['id'])) {
    $story_id = intval($_GET['id']);

    // Check if user owns this story
    $check = $conn->prepare("SELECT name FROM stories WHERE id = ?");
    $check->bind_param("i", $story_id);
    $check->execute();
    $check->bind_result($story_owner);
    $check->fetch();
    $check->close();

    if ($story_owner !== $username) {
        echo "<script>alert('You can only delete your own story!'); window.location.href='viewstory.php';</script>";
        exit;
    }

    // Delete the story
    $delete = $conn->prepare("DELETE FROM stories WHERE id = ?");
    $delete->bind_param("i", $story_id);
    $delete->execute();
    $delete->close();

    echo "<script>alert('Story deleted successfully!'); window.location.href='viewstory.php';</script>";
    exit;
} else {
    header("Location: viewstory.php");
    exit;
}
?>