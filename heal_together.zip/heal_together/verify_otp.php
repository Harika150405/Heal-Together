<?php
session_start();
include("connection.php");

if (isset($_POST['verify_otp'])) {
    $otp = mysqli_real_escape_string($conn, $_POST['otp']);

    if (isset($_SESSION['otp']) && isset($_SESSION['email'])) {
        $stored_otp = $_SESSION['otp'];
        $email = $_SESSION['email'];

        if ($otp == $stored_otp) {

            // ✅ Remove this (This was wrong)
            // mysqli_query($conn, "UPDATE form SET verified=1 WHERE email='$email'");

            unset($_SESSION['otp']); // OTP used

            echo "<script>alert('OTP verified successfully!'); window.location='reset_password.php';</script>";
            exit;
        } else {
            echo "<script>alert('Invalid OTP. Please try again.');</script>";
        }
    } else {
        echo "<script>alert('Session expired. Please try again.'); window.location='forgot_password.php';</script>";
    }
}
?>

<!DOCTYPE html>
<html lang='en'>
<head>
    <meta charset='UTF-8'>
    <meta name='viewport' content='width=device-width, initial-scale=1.0'>
    <title>Verify OTP</title>
    <link rel='stylesheet' href='form-style.css'>
</head>
<body>
    <div class='container'>
        <div class='title'>Verify Your OTP</div>
        <form method='POST'>
            <div class='form'>
                <div class='input_field'>
                    <label>Enter OTP</label>
                    <input type='text' class='input' name='otp' required>
                </div>
                <div class='input_field'>
                    <input type='submit' value='Verify OTP' class='btn' name='verify_otp'>
                </div>
            </div>
        </form>
    </div>
</body>
</html>
