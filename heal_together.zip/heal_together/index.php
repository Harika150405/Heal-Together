<?php
include("connection.php");
session_start();
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" href="login-style.css">
    <title>Login Page</title>

    <style>
       body {
            margin: 0;
            padding: 0;
            background: url('https://imageio.forbes.com/specials-images/imageserve/645403962766f9dc50eabd27/0x0.jpg?format=jpg&crop=1640,1228,x61,y0,safe&height=600&width=1200&fit=bounds')
                        no-repeat center center fixed;
            background-size: cover;
            font-family: Arial, sans-serif;
        }
    </style>
</head>
<body>
    <div class="center">
        <h1>Login</h1>
        <div class="form">
            <form method="POST" autocomplete="off">
                <input type="text" name="username" class="textfield" placeholder="Username" required>
                <input type="password" name="password" class="textfield" placeholder="Password" required>
                <div class="forgetpass">
                    <a href="forgot_password.php" class="link">Forget Password</a>
                </div>
                <input type="submit" name="login" value="Login" class="btn">
            </form>
            <div class="signup">
                New Member? <a href="form.php" class="link">SignUp Here</a>
            </div>
        </div>
    </div>
</body>
</html>

<?php
if (isset($_POST['login'])) {
    $username = $_POST['username'];
    $pwd = $_POST['password'];

    // ✅ Check user by username and password from 'form' table
    $query = "SELECT username, email FROM form WHERE username = ? AND password = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("ss", $username, $pwd);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 1) {
        $row = $result->fetch_assoc();

        // ✅ Save username and email in session
        $_SESSION['username'] = $row['username'];
        $_SESSION['email'] = $row['email'];

        header("Location: index_home.html");
        exit;
    } else {
        echo "<script>alert('Login Failed: Invalid Username or Password');</script>";
    }

    $stmt->close();
    $conn->close();
}
?>
