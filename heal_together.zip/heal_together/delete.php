<?php
include("connection.php");

$id = $_GET['id'];

$query = "DELETE FROM form WHERE id = '$id'";
$data = mysqli_query($conn, $query);

if ($data) {
    echo "<script>
            alert('Record Deleted Successfully');
            window.location.href = 'display.php';
          </script>";
} else {
    echo "<script>
            alert('Failed to Delete Record');
            window.location.href = 'display.php';
          </script>";
}
?>
