<?php
session_start();
include("connection.php");

if (!isset($_SESSION['email'])) {
    echo "<script>alert('Session expired. Please register again.'); window.location='form.php';</script>";
    exit();
}

if (isset($_POST['verify'])) {
    $entered_otp = $_POST['otp'];
    $email = $_SESSION['email'];

    if ($entered_otp == $_SESSION['otp']) {
        $update = "UPDATE form SET verified = 1 WHERE email = '$email'";
        mysqli_query($conn, $update);
        echo "<script>alert('Email verified successfully!'); window.location='index.php';</script>";
    } else {
        echo "<script>alert('Invalid OTP. Please try again.');</script>";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>OTP Verification</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f2f2f2;
            display: flex;
            height: 100vh;
            align-items: center;
            justify-content: center;
        }
        .otp-box {
            background: white;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 0 10px rgba(0,0,0,0.3);
        }
        input {
            padding: 10px;
            width: 100%;
            margin-top: 10px;
        }
        button {
            padding: 10px 15px;
            margin-top: 15px;
            background: green;
            color: white;
            border: none;
            cursor: pointer;
            border-radius: 8px;
        }
    </style>
</head>
<body>
    <div class="otp-box">
        <h2>Enter OTP sent to your email</h2>
        <form method="POST">
            <input type="text" name="otp" placeholder="Enter 6-digit OTP" required>
            <button type="submit" name="verify">Verify</button>
        </form>
    </div>
</body>
</html>
