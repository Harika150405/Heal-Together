<?php
include 'dbconnection.php';
error_reporting(E_ALL);
ini_set('display_errors', 1);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name']);
    $community = trim($_POST['community']);
    $story = trim($_POST['story']);

    // Basic validation
    if (!empty($name) && !empty($community) && !empty($story)) {
        // Prepare SQL
        $stmt = $conn->prepare("INSERT INTO stories (name, community, story) VALUES (?, ?, ?)");

        if ($stmt) {
            $stmt->bind_param("sss", $name, $community, $story);

            if ($stmt->execute()) {
                echo "<script>alert('Your story has been shared successfully!'); window.location.href='viewstory.php';</script>";
            } else {
                echo "<script>alert('Something went wrong while submitting.'); window.location.href='newstory.php';</script>";
            }

            $stmt->close();
        } else {
            // SQL error debug
            die("SQL error: " . $conn->error);
        }
    } else {
        echo "<script>alert('Please fill in all fields.'); window.history.back();</script>";
    }
}

$conn->close();
?>