<?php
include '../connection.php';
session_start();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $community = $_POST['group'] ?? '';
    $username = $_SESSION['username'] ?? '';
    $message = $_POST['message'] ?? '';

    if (!empty($community) && !empty($username) && !empty($message)) {
        $sql = "INSERT INTO messages (community_name, username, message, timestamp) VALUES (?, ?, ?, NOW())";
        $stmt = $conn->prepare($sql);

        if (!$stmt) {
            die("SQL Prepare Failed: " . $conn->error);
        }

        $stmt->bind_param("sss", $community, $username, $message);
        $stmt->execute();
        $stmt->close();
    }
}
?>
