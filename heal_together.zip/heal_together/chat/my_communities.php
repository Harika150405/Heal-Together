<?php
session_start();
include('../connection.php');

if (!isset($_SESSION['username'])) {
    echo "<script>alert('You must be logged in first!'); window.location.href='../login.html';</script>";
    exit;
}

$username = $_SESSION['username'];

// Fetch latest joined communities
$query = $conn->prepare("SELECT community_name FROM joined_communities WHERE username = ? ORDER BY id DESC");
$query->bind_param("s", $username);
$query->execute();
$result = $query->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>My Communities</title>
    <style>
        body {
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(135deg, #f3e7ff, #ede0ff);
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }

        .container {
            background: white;
            padding: 30px;
            border-radius: 20px;
            box-shadow: 0 0 20px rgba(138, 43, 226, 0.1);
            width: 450px;
            text-align: center;
        }

        h1 {
            color: #6c2bd9;
            font-size: 26px;
            margin-bottom: 10px;
        }

        h3 {
            color: #666;
            margin-bottom: 25px;
        }

        .community-card {
            border: 2px solid #cbb5f9;
            border-radius: 15px;
            padding: 15px 20px;
            margin-bottom: 15px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            background: #f8f4ff;
            transition: all 0.3s ease;
        }

        .community-card:hover {
            background-color: #f2eaff;
            transform: translateY(-3px);
        }

        .community-name {
            font-size: 18px;
            color: #4b0082;
            font-weight: 500;
        }

        .join-btn {
            background-color: #8a2be2;
            color: white;
            border: none;
            padding: 8px 18px;
            border-radius: 10px;
            font-size: 14px;
            cursor: pointer;
            transition: background 0.3s;
        }

        .join-btn:hover {
            background-color: #6d1fc4;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>My Communities</h1>
        <h3>Hi <strong><?php echo htmlspecialchars($username); ?></strong> 👋</h3>

        <?php
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                echo '<div class="community-card">';
                echo '<div class="community-name">' . htmlspecialchars($row['community_name']) . '</div>';
                echo '<button class="join-btn" onclick="openChat(\'' . htmlspecialchars($row['community_name']) . '\')">Open Chat</button>';
                echo '</div>';
            }
        } else {
            echo "<p>You haven't joined any communities yet.</p>";
        }
        ?>
    </div>

    <script>
        function openChat(groupName) {
            window.location.href = "chat.php?group=" + encodeURIComponent(groupName);

        }
    </script>
</body>
</html>
