<?php
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: ../login.php");
    exit();
}
$username = $_SESSION['username'];
$community = isset($_GET['group']) ? $_GET['group'] : 'General';
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width,initial-scale=1" />
<title><?php echo htmlspecialchars($community); ?> — Chat Room</title>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;500;700&display=swap" rel="stylesheet">
<style>
  :root{
    --bg1:#f9f5ff;
    --bg2:#f3e9ff;
    --accent1:#b196ff;
    --accent2:#9d84ff;
    --me-bubble:linear-gradient(135deg,#bba9ff,#a992ff);
    --other-bubble:#ffffff;
    --border:#d9c8ff;
    --muted:#5c4b7d;
  }

  *{box-sizing:border-box;}
  body{
    margin:0;
    font-family:'Poppins',sans-serif;
    background:linear-gradient(135deg,var(--bg1),var(--bg2));
    height:100vh;display:flex;align-items:center;justify-content:center;
  }

  .wrap{
    width:92%;max-width:1200px;height:86vh;border-radius:18px;
    background:#fffefcde;box-shadow:0 10px 30px rgba(100,75,150,0.15);
    display:flex;overflow:hidden;
  }

  .sidebar{
    width:24%;min-width:220px;padding:24px;
    background:#f4edff;border-right:1px solid #e3d6ff;
  }
  .sidebar h2{margin:0 0 14px;color:var(--accent2);font-size:20px;}
  .online-list{margin:0;padding:0;list-style:none;}
  .online-list li{
    padding:10px 12px;margin-bottom:10px;border-radius:10px;
    background:#f8f4ff;color:var(--accent2);font-weight:600;
  }

  .chat-area{flex:1;display:flex;flex-direction:column;}
  .chat-header{
    padding:16px;text-align:center;
    background:linear-gradient(90deg,var(--accent1),var(--accent2));
    color:white;font-weight:600;font-size:18px;
  }

  .chat-main{
    flex:1;
    overflow-y:auto;
    padding:20px 24px;
    display:flex;
    flex-direction:column;
    gap:10px;
    background:linear-gradient(180deg,#fff,#faf7ff);
  }

  .msg-row{
    display:flex;
    flex-direction:column;
    align-items:flex-start;
  }

  .msg{
    display:inline-block;
    padding:10px 14px;
    border-radius:14px;
    font-size:15px;
    box-shadow:0 4px 12px rgba(91,63,208,0.06);
    max-width:60%;
    width:fit-content;
    word-wrap:break-word;
  }
  .msg .who{font-size:13px;color:var(--muted);margin-bottom:4px;font-weight:600;}
  .msg .txt{white-space:pre-wrap;line-height:1.35;}
  .msg .time{font-size:11px;color:#7a6fa6;margin-top:6px;text-align:right;}

  .other{
    align-self:flex-start;
    background:var(--other-bubble);
    border:1px solid var(--border);
    color:#443563;
    border-bottom-left-radius:4px;
  }

  .me{
    align-self:flex-end;
    background:var(--me-bubble);
    color:white;
    border-bottom-right-radius:4px;
    margin-right:0;
  }

  .chat-input{
    padding:16px;display:flex;gap:12px;align-items:center;
    border-top:1px solid #e3d6ff;background:#f9f6ff;
  }
  .chat-input input[type="text"]{
    flex:1;
    padding:12px 16px;
    border-radius:24px;
    border:1px solid #d8cfff;
    font-size:15px;
    outline:none;
    background:white;
    min-width:0;
  }
  .chat-input button{
    background:linear-gradient(90deg,var(--accent1),var(--accent2));
    color:white;border:none;padding:10px 18px;border-radius:14px;
    cursor:pointer;font-weight:600;box-shadow:0 6px 16px rgba(91,63,208,0.18);
  }

  .system{
    align-self:center;
    background:rgba(255,255,255,0.7);
    color:var(--muted);
    border-radius:12px;
    padding:10px 12px;
    font-weight:600;
  }

  @media (max-width:880px){
    .wrap{width:98%;height:94vh;}
    .sidebar{display:none;}
  }
</style>
</head>
<body>

<div class="wrap">
  <div class="sidebar">
    <h2>Online Users</h2>
    <ul id="onlineUsers" class="online-list"><li>Loading...</li></ul>
  </div>

  <div class="chat-area">
    <div class="chat-header">
      Chat Room — <?php echo htmlspecialchars($community); ?>
    </div>

    <div id="chatMain" class="chat-main" aria-live="polite"></div>

    <div class="chat-input">
      <input id="msgInput" type="text" placeholder="Type your message..." aria-label="Message input">
      <button id="sendBtn">Send</button>
    </div>
  </div>
</div>

<script>
const username = <?php echo json_encode($username); ?>;
const community = <?php echo json_encode($community); ?>;
const chatMain = document.getElementById('chatMain');
const onlineUsersEl = document.getElementById('onlineUsers');
const input = document.getElementById('msgInput');
const sendBtn = document.getElementById('sendBtn');

function formatTime(ts){
  const d = new Date(ts);
  return d.toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'});
}

async function loadMessages(){
  try{
    const res = await fetch(`getmessages.php?group=${encodeURIComponent(community)}`);
    const data = await res.json();
    chatMain.innerHTML = '';
    if(data.length === 0){
      const sys = document.createElement('div');
      sys.className='system';
      sys.textContent='No messages yet — start chatting!';
      chatMain.appendChild(sys);
    } else {
      data.forEach(m=>{
        const wrapper=document.createElement('div');
        wrapper.className='msg-row';
        const el=document.createElement('div');
        el.className='msg '+(m.username===username?'me':'other');
        el.innerHTML=`
          <div class="who">${m.username===username?'You':m.username}</div>
          <div class="txt">${escapeHtml(m.message)}</div>
          <div class="time">${formatTime(m.timestamp)}</div>`;
        wrapper.appendChild(el);
        chatMain.appendChild(wrapper);
      });
    }
    chatMain.scrollTop=chatMain.scrollHeight;
  }catch(err){console.error(err);}
}

async function loadOnline(){
  try{
    const res=await fetch(`onlineusers.php?group=${encodeURIComponent(community)}`);
    const html=await res.text();
    onlineUsersEl.innerHTML=html;
  }catch(err){console.error(err);}
}

async function sendMessage(){
  const text=input.value.trim();
  if(!text) return;
  const fd=new URLSearchParams();
  fd.append('message',text);
  fd.append('group',community);

  try{
    const res=await fetch('savemessage.php',{
      method:'POST',
      headers:{'Content-Type':'application/x-www-form-urlencoded'},
      body:fd.toString()
    });
    if(!res.ok) throw new Error('Save failed');
    input.value='';
    await loadMessages();
  }catch(err){console.error(err);}
}

function escapeHtml(s){
  return s.replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;').replaceAll('"','&quot;');
}

sendBtn.addEventListener('click',sendMessage);
input.addEventListener('keydown',e=>{if(e.key==='Enter')sendMessage();});

setInterval(loadMessages,2000);
setInterval(loadOnline,5000);
loadMessages(); loadOnline();
</script>
</body>
</html>
