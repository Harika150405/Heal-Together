<?php
include '../connection.php';
session_start();

if (!isset($_SESSION['username']) || !isset($_GET['group'])) {
    echo "<li>No users</li>";
    exit();
}
$username = $conn->real_escape_string($_SESSION['username']);
$group = $conn->real_escape_string($_GET['group']);

// ensure table exists (safe)
$conn->query("
CREATE TABLE IF NOT EXISTS joined_communities (
  id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(100) NOT NULL,
  community_name VARCHAR(100) NOT NULL,
  last_active DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY unique_user_group (username, community_name)
)");
 
// insert or update this user's last_active
$conn->query("INSERT INTO joined_communities (username, community_name, last_active) VALUES ('$username','$group', NOW()) ON DUPLICATE KEY UPDATE last_active = NOW()");

// select active users (2 minutes)
$res = $conn->query("SELECT username FROM joined_communities WHERE community_name = '$group' AND last_active > NOW() - INTERVAL 2 MINUTE ORDER BY username ASC");
if (!$res) {
    echo "<li>Error</li>";
    exit();
}
if ($res->num_rows === 0) {
    echo "<li>No users online</li>";
    exit();
}
while ($r = $res->fetch_assoc()) {
    $u = htmlspecialchars($r['username']);
    echo "<li>" . $u . ($r['username'] === $_SESSION['username'] ? " (You)" : "") . "</li>";
}
