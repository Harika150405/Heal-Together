const socket = io();
const username = localStorage.getItem("username"); // already set at login
const community = localStorage.getItem("community"); // set from chat.html

// redirect to select community if missing
if (!username) {
  alert("Please log in first!");
  window.location.href = "login.html"; // change if your login page has a different name
}
if (!community) {
  window.location.href = "chat.html";
}

const msgInput = document.getElementById("msgInput");
const sendBtn = document.getElementById("sendBtn");
const messages = document.getElementById("messages");
const usersList = document.getElementById("users");

// join room
socket.emit("setUsername", username);
socket.emit("joinRoom", community);

// send message
sendBtn.addEventListener("click", sendMessage);
msgInput.addEventListener("keypress", (e) => e.key === "Enter" && sendMessage());

function sendMessage() {
  const msg = msgInput.value.trim();
  if (msg) {
    socket.emit("sendMessage", msg);
    msgInput.value = "";
  }
}

// handle messages
socket.on("chatMessage", ({ user, msg }) => {
  const div = document.createElement("div");
  div.classList.add("msg");
  div.classList.add(user === username ? "my-msg" : "other-msg");
  div.innerHTML = `<strong>${user}</strong><p>${msg}</p>`;
  messages.appendChild(div);
  messages.scrollTop = messages.scrollHeight;
});

socket.on("systemMessage", (text) => {
  const div = document.createElement("div");
  div.classList.add("system-msg");
  div.textContent = text;
  messages.appendChild(div);
  messages.scrollTop = messages.scrollHeight;
});

socket.on("updateUsers", (users) => {
  usersList.innerHTML = "";
  users.forEach((u) => {
    const li = document.createElement("li");
    li.textContent = u;
    usersList.appendChild(li);
  });
});