import express from "express";
import http from "http";
import { Server } from "socket.io";
import path from "path";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const server = http.createServer(app);
const io = new Server(server);

app.use(express.static(path.join(__dirname, "public")));

let users = {}; // socket.id -> { username, room }
let rooms = {}; // room -> Set of usernames

io.on("connection", (socket) => {
  socket.on("setUsername", (username) => {
    users[socket.id] = { username, room: null };
  });

  socket.on("joinRoom", (room) => {
    const user = users[socket.id];
    if (!user) return;

    if (user.room) {
      socket.leave(user.room);
      rooms[user.room]?.delete(user.username);
    }

    socket.join(room);
    user.room = room;

    if (!rooms[room]) rooms[room] = new Set();
    rooms[room].add(user.username);

    io.to(room).emit("updateUsers", Array.from(rooms[room]));
    io.to(room).emit("systemMessage", `${user.username} joined ${room}`);
  });

  socket.on("sendMessage", (msg) => {
    const user = users[socket.id];
    if (user?.room) {
      io.to(user.room).emit("chatMessage", { user: user.username, msg });
    }
  });

  socket.on("disconnect", () => {
    const user = users[socket.id];
    if (user?.room) {
      rooms[user.room]?.delete(user.username);
      io.to(user.room).emit("updateUsers", Array.from(rooms[user.room]));
      io.to(user.room).emit("systemMessage", `${user.username} left the chat`);
    }
    delete users[socket.id];
  });
});

server.listen(4000, () =>
  console.log("HealTogether chat server running at http://localhost:4000")
);