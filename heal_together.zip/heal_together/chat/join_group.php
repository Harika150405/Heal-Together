<?php
session_start();
include("../connection.php"); // adjust if your connection path is different

if (!isset($_SESSION['username'])) {
    echo "no_user";
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $username = $_SESSION['username'];
    $group = mysqli_real_escape_string($conn, $_POST['group_name']);

    // Check if already joined
    $check = "SELECT * FROM joined_communities WHERE username='$username' AND community_name='$group'";
    $result = mysqli_query($conn, $check);

    if (mysqli_num_rows($result) > 0) {
        echo "already";
        exit();
    }

    // Insert record
    $query = "INSERT INTO joined_communities (username, community_name) VALUES ('$username', '$group')";
    if (mysqli_query($conn, $query)) {
        echo "success";
    } else {
        echo "error";
    }
}
?>
