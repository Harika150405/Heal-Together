<?php
include '../connection.php';
session_start();

$group = isset($_GET['group']) ? $_GET['group'] : '';

if ($group === '') {
    echo json_encode([]);
    exit();
}

$group_esc = $conn->real_escape_string($group);
$sql = "SELECT username, message, timestamp FROM messages WHERE community_name = ? ORDER BY timestamp ASC";
$stmt = $conn->prepare($sql);
if (!$stmt) {
    http_response_code(500);
    echo json_encode(["error"=>$conn->error]);
    exit();
}
$stmt->bind_param("s", $group);
$stmt->execute();
$res = $stmt->get_result();
$out = [];
while($row = $res->fetch_assoc()){
  // timestamp as iso-friendly string
  $out[] = [
    'username' => $row['username'],
    'message' => $row['message'],
    'timestamp' => $row['timestamp']
  ];
}
$stmt->close();
header('Content-Type: application/json');
echo json_encode($out);
