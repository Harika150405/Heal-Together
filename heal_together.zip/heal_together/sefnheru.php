<?php
session_start();
include("connection.php");

if (!isset($_SESSION['username'])) {
    echo "Please log in first.";
    exit();
}

$user_email = $_SESSION['username'];
$group = $_POST['group'] ?? '';

if (empty($group)) {
    echo "Invalid group name.";
    exit();
}

// Step 1: Get the group ID
$groupQuery = "SELECT id FROM community_groups WHERE group_name = '$group'";
$groupResult = mysqli_query($conn, $groupQuery);
$groupRow = mysqli_fetch_assoc($groupResult);

if (!$groupRow) {
    echo "Group not found.";
    exit();
}

$group_id = $groupRow['id'];

// Step 2: Check if already joined
$checkQuery = "SELECT * FROM user_groups WHERE user_email = '$user_email' AND group_id = '$group_id'";
$checkResult = mysqli_query($conn, $checkQuery);

if (mysqli_num_rows($checkResult) > 0) {
    echo "You have already joined this group.";
    exit();
}

// Step 3: Insert into user_groups
$insertQuery = "INSERT INTO user_groups (user_email, group_id) VALUES ('$user_email', '$group_id')";
if (!mysqli_query($conn, $insertQuery)) {
    echo "Error joining group: " . mysqli_error($conn);
    exit();
}

// Step 4: Update members count
mysqli_query($conn, "UPDATE community_groups SET members_count = members_count + 1 WHERE id = '$group_id'");

// Step 5: Update joined_groups column in form
// Fetch existing joined groups (if any)
$getJoined = mysqli_query($conn, "SELECT joined_groups FROM form WHERE email = '$user_email'");
$row = mysqli_fetch_assoc($getJoined);
$currentGroups = $row['joined_groups'] ?? '';

if ($currentGroups != '') {
    // Append new group name
    $updatedGroups = $currentGroups . ',' . $group;
} else {
    $updatedGroups = $group;
}

$updateQuery = "UPDATE form SET joined_groups = '$updatedGroups' WHERE email = '$user_email'";
mysqli_query($conn, $updateQuery);

echo "Successfully joined $group group!";
?>
