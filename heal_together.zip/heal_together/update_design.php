<?php 
include("connection.php"); 
$id = $_GET['id'];
$query = "SELECT * FROM form WHERE id = '$id'";
$data = mysqli_query($conn, $query);
$result = mysqli_fetch_assoc($data);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Details</title>
    <link rel="stylesheet" href="form-style.css">
</head>
<body>
    <div class="container">
        <div class="title">Update Details</div>
        <form method="POST">
            <div class="form">
                <div class="input_field">
                    <label>First Name</label>
                    <input type="text" class="input" name="fname" value="<?php echo $result['fname']; ?>" required>
                </div>
                <div class="input_field">
                    <label>Last Name</label>
                    <input type="text" class="input" name="lname" value="<?php echo $result['lname']; ?>" required>
                </div>
                <div class="input_field">
                    <label>New Password</label>
                    <input type="password" class="input" name="password" placeholder="Enter new password">
                </div>
                <div class="input_field">
                    <label>Confirm Password</label>
                    <input type="password" class="input" name="conpassword" placeholder="Confirm new password">
                </div>
                <div class="input_field">
                    <label>Gender</label>
                    <div class="selectbox">
                        <select name="gender" required>
                            <option value="">Select</option>
                            <option value="male" <?php if($result['gender']=='male') echo 'selected'; ?>>Male</option>
                            <option value="female" <?php if($result['gender']=='female') echo 'selected'; ?>>Female</option>
                        </select>
                    </div>
                </div>
                <div class="input_field">
                    <label>Email Address</label>
                    <input type="email" class="input" name="email" value="<?php echo $result['email']; ?>" required>
                </div>
                <div class="input_field">
                    <label>Phone Number</label>
                    <input type="text" class="input" name="phone" value="<?php echo $result['phone']; ?>" required>
                </div>
                <div class="input_field">
                    <label>Address</label>
                    <textarea class="textarea" name="address" required><?php echo $result['address']; ?></textarea>
                </div>

                <div class="input_field">
                    <input type="submit" value="Update Details" class="btn" name="update">
                </div>
            </div>
        </form>
    </div>
</body>
</html>

<?php 
if (isset($_POST['update'])) {
    $fname = $_POST['fname'];
    $lname = $_POST['lname'];
    $pwd = $_POST['password'];
    $cpwd = $_POST['conpassword'];
    $gender = $_POST['gender'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $address = $_POST['address'];

    if ($pwd || $cpwd) { // if user entered new password
        if ($pwd !== $cpwd) {
            echo "<script>alert('Passwords do not match');</script>";
            exit();
        }
        $hashed_password = password_hash($pwd, PASSWORD_DEFAULT);
        $query = "UPDATE form SET 
            fname='$fname', 
            lname='$lname', 
            password='$hashed_password',
            gender='$gender',
            email='$email',
            phone='$phone',
            address='$address'
            WHERE id='$id'";
    } else { 
        $query = "UPDATE form SET 
            fname='$fname', 
            lname='$lname', 
            gender='$gender',
            email='$email',
            phone='$phone',
            address='$address'
            WHERE id='$id'";
    }

    $data = mysqli_query($conn, $query);

    if ($data) {
        echo "<script>alert('Record Updated Successfully'); window.location='display.php';</script>";
    } else {
        echo "<script>alert('Failed to Update Record');</script>";
    }
}
?>
