function joinGroup(groupName) {
    fetch("chat/join_group.php", {
        method: "POST",
        headers: {
            "Content-Type": "application/x-www-form-urlencoded"
        },
        body: "group_name=" + encodeURIComponent(groupName)   // ✅ FIXED
    })
    .then(response => response.text())
    .then(() => {
        window.location.href = "chat/chat.php?community=" + encodeURIComponent(groupName);
    })
    .catch(error => console.error("Error:", error));
}
