<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// Include PHPMailer files
require 'PHPMailer/src/Exception.php';
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $userEmail = $_POST['email'];
    $subject = $_POST['subject'];
    $description = $_POST['description'];

    // Receiver email (your email)
    $toEmail = "youremail@example.com";  // ← change this to YOUR email address

    $mail = new PHPMailer(true);

    try {
        // SMTP Configuration (for Gmail)
        $mail->isSMTP();
        $mail->Host       = 'smtp.gmail.com';
        $mail->SMTPAuth   = true;
        $mail->Username = 'yanapartiharika@gmail.com';      // your Gmail
        $mail->Password = 'bcztdzhhwlelzssz';        // Gmail App Password
        $mail->SMTPSecure = 'ssl';
        $mail->Port = 465;

        // Email settings
        $mail->setFrom('yanapartiharika@gmail.com', 'Heal Together');
        $mail->addAddress($toEmail, 'HealTogether Support');
        $mail->addReplyTo($userEmail);

        $mail->isHTML(true);
        $mail->Subject = "New Support Request: " . htmlspecialchars($subject);
        $mail->Body    = "
            <h3>New Support Request</h3>
            <p><strong>Email:</strong> {$userEmail}</p>
            <p><strong>Subject:</strong> {$subject}</p>
            <p><strong>Description:</strong><br>" . nl2br(htmlspecialchars($description)) . "</p>
        ";

        $mail->send();
        echo "<script>alert('Your request has been submitted successfully!'); window.location.href='page4.html';</script>";
    } catch (Exception $e) {
        echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
    }
}
?>
