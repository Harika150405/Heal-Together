<!DOCTYPE html>
<html>
<head>
    <title>Display Records</title>
    <style>
        body {
            background: #D071f9;
            font-family: Arial, sans-serif;
        }
        table {
            background-color: white;
            border-collapse: collapse;
            width: 100%;
            margin-top: 20px;
        }
        th, td {
            padding: 7px;
            text-align: center;
        }
        th {
            background-color: white;
            color: black;
        }
        tr:nth-child(even) {
            background-color: #f2f2f2;
        }
        h2 {
            text-align: center;
            color: black;
        }
        a {
            text-decoration: none;
            padding: 5px 10px;
            border-radius: 5px;
            color: white;
        }
        .update {
            background-color: #28a745;
        }
        .delete {
            background-color: #dc3545;
        }
        a:hover {
            opacity: 0.8;
        }
    </style>
</head>

<body>
<?php
include("connection.php");

$query = "SELECT * FROM form";
$data = mysqli_query($conn, $query);
$total = mysqli_num_rows($data);

if ($total != 0) {
    echo "<h2>Displaying All Records</h2>";
    echo "<center><table border='1' cellspacing='7' cellpadding='10'>
            <tr>
                <th>ID</th>
                <th>First Name</th>
                <th>Last Name</th>
                <th>Gender</th>
                <th>Email</th>
                <th>Phone</th>
                <th>Address</th>
                <th>Operations</th>
            </tr>";

    while ($result = mysqli_fetch_assoc($data)) {
        $id = $result['id'];
        $fname = $result['fname'];
        $lname = $result['lname'];
        $gender = $result['gender'];
        $email = $result['email'];
        $phone = $result['phone'];
        $address = $result['address'];

        echo "<tr>
                <td>$id</td>
                <td>$fname</td>
                <td>$lname</td>
                <td>$gender</td>
                <td>$email</td>
                <td>$phone</td>
                <td>$address</td>
                <td>
                    <a href='update_design.php?id=$id' class='update'>Update</a>
                    <a href='delete.php?id=$id' class='delete' 
                       onclick='return confirm(\"Are you sure you want to delete this record?\");'>
                       Delete
                    </a>
                </td>
              </tr>";
    }

    echo "</table></center>";
} else {
    echo "<h3 style='text-align:center; color:white;'>No records found</h3>";
}
?>
</body>
</html>
