<?php
session_start();
include("connection.php");

if (!isset($_SESSION['otp']) || !isset($_SESSION['email'])) {
    echo "<script>alert('OTP session expired!'); window.location='forgot_password.php';</script>";
    exit;
}

if (isset($_POST['verify'])) {
    $enteredOtp = trim($_POST['otp']);
    $sessionOtp = $_SESSION['otp'];
    $email = $_SESSION['email'];

    if (time() - $_SESSION['otp_time'] > 300) { // 5 minutes
        echo "<script>alert('OTP expired! Please request again.'); window.location='forgot_password.php';</script>";
        exit;
    }

    if ($enteredOtp == $sessionOtp) {
        // Redirect to password reset page
        echo "<script>alert('OTP verified successfully!'); window.location='reset_password.php';</script>";
        exit;
    } else {
        echo "<script>alert('Invalid OTP! Please try again.');</script>";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Verify OTP</title>
</head>
<body style="background:#D071F9; font-family:Arial;">
    <div style="margin:100px auto; width:300px; background:#fff; padding:20px; border-radius:10px;">
        <h2>Verify OTP</h2>
        <form method="POST">
            <input type="text" name="otp" placeholder="Enter OTP" required style="width:90%; padding:8px;"><br><br>
            <input type="submit" name="verify" value="Verify OTP" style="width:100%; padding:8px; background:#D071F9; color:white; border:none;">
        </form>
    </div>
</body>
</html>
